<!-- Footer -->
<footer class="border-t border-slate-200 py-4 text-center text-sm text-slate-500">
    <p>&copy; 2025 AdminPanel. All rights reserved.</p>
</footer>