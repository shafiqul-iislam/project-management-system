<?php
namespace App\View\Components;

use Illuminate\View\Component;

class DeveloperLayout extends Component
{
    public function render()
    {
        return view('developer.layouts.app');
    }
}