<x-admin-layout>
    <div class="max-w-7xl mx-auto px-6 py-10">

        <!-- Page Title -->
        <div class="mb-8">
            <h1 class="text-2xl font-bold text-slate-800">Tasks</h1>
            <p class="text-slate-500 mt-1">Overview of all tasks across projects.</p>
        </div>

        <!-- Tasks Table -->
        <div class="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm text-slate-600">
                    <thead class="bg-slate-50 border-b border-slate-200">
                        <tr>
                            <th class="px-6 py-4 font-semibold text-slate-700">Task Title</th>
                            <th class="px-6 py-4 font-semibold text-slate-700">Project</th>
                            <th class="px-6 py-4 font-semibold text-slate-700">Developer</th>
                            <th class="px-6 py-4 font-semibold text-slate-700">Priority</th>
                            <th class="px-6 py-4 font-semibold text-slate-700">Status</th>
                            <th class="px-6 py-4 font-semibold text-slate-700">Created At</th>
                            <th class="px-6 py-4 font-semibold text-slate-700">Updated At</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        @forelse($tasks as $task)
                        <tr class="hover:bg-slate-50 transition">
                            <td class="px-6 py-4 font-medium text-slate-900">
                                {{ $task->title }}
                            </td>
                            <td class="px-6 py-4">
                                @if($task->project)
                                <span class="text-primary font-medium">{{ $task->project->name }}</span>
                                @else
                                <span class="text-slate-400 italic">No Project</span>
                                @endif
                            </td>
                            <td class="px-6 py-4">
                                @if($task->developer)
                                <span class="text-primary font-medium">{{ $task->developer->name }}</span>
                                @else
                                <span class="text-slate-400 italic">No Developer</span>
                                @endif
                            </td>
                            <td class="px-6 py-4">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                                    {{ $task->priority == 'high' ? 'bg-red-100 text-red-700' : '' }}
                                    {{ $task->priority == 'medium' ? 'bg-orange-100 text-orange-700' : '' }}
                                    {{ $task->priority == 'low' ? 'bg-emerald-100 text-emerald-700' : '' }}">
                                    {{ ucfirst($task->priority) }}
                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium {{ $task->status->color() }}">
                                    {{ $task->status->label() }}
                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <div class="text-slate-900 font-medium">{{ $task->created_at->format('M d, Y') }}</div>
                                <div class="text-xs text-slate-500">{{ $task->created_at->diffForHumans() }}</div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="text-slate-900 font-medium">{{ $task->updated_at->format('M d, Y') }}</div>
                                <div class="text-xs text-slate-500">{{ $task->updated_at->diffForHumans() }}</div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" class="px-6 py-10 text-center text-slate-500">
                                No tasks found.
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</x-admin-layout>